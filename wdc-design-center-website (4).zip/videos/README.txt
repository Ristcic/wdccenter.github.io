Drop your own video clips in this folder using these exact file names,
then redeploy — they'll activate automatically:

  hero-loop.mp4          Short (5–15 sec), silent, looping background clip
                         for the hero section — e.g. a slow pan across a
                         finished install. Also add images/hero-poster.jpg
                         as the fallback frame for slow connections.

  walkthrough.mp4        A longer clip (1–3 min is plenty) for the
                         "See Us In Action" section — a real install
                         walkthrough, before/after, or client testimonial.
                         Also add images/walkthrough-poster.jpg as its
                         thumbnail/poster frame.

Tips:
  - Keep hero-loop.mp4 small (under ~5MB) since it autoplays for every visitor.
  - walkthrough.mp4 has playback controls, so it only loads when a visitor
    presses play — file size matters less there.
  - Export both as standard H.264 .mp4 for the widest browser support.
  - If a file isn't present, that section just shows its current fallback
    design — nothing breaks.
