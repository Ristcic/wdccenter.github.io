# WDC Design Center — Website

A complete, static marketing site: hero, services (windows/doors/cabinets), process, gallery, reviews, contact form, and footer. No build step required — plain HTML/CSS/JS.

**Design:** warm, editorial palette (cream/white surfaces, brass/gold + soft slate-blue accents, deep charcoal contrast sections) built to match real cabinetry photography, paired with Fraunces (display serif) + Inter (body) + IBM Plex Mono (labels). The header/footer logo is an animated inline SVG (draws itself in on load, pulses on hover), the hero and "Why" sections feature real project photos in framed panels with subtle reveal animations, and cards/sections fade in on scroll.

## Deploy to Netlify (drag-and-drop, ~1 minute)

1. Unzip this folder on your computer.
2. Go to https://app.netlify.com and log in (or create a free account).
3. On your dashboard, find the **"Add new site" → "Deploy manually"** option (or the drag-and-drop box on the Sites page).
4. Drag the whole unzipped folder into that box.
5. Netlify will publish it instantly and give you a live URL like `https://random-name-123.netlify.app`.
6. Optional: click **Site settings → Change site name** to pick a custom `.netlify.app` subdomain, or **Domain settings → Add a custom domain** to use your own domain (e.g. `wdcdesigncenter.com`).

That's it — the site is live and publicly accessible.

## Before you launch, update these placeholders

Open `index.html` and replace:

- **Phone number** — currently `(555) 123-4567` / `tel:+15551234567` (appears in the header, hero note, and contact section)
- **Email** — currently `info@wdcdesigncenter.com`
- **Service area** — currently "Greater Metro Area & Surrounding Counties"
- **Business hours** — currently "Mon–Fri, 7:00am–5:00pm"
- **Stats** — "15+ years", "1,200+ installs" in the hero — swap in your real numbers
- **Reviews** — the three testimonials are placeholders; swap in real client quotes when you have them

## Adding your own photos and video

The site ships with clean placeholder icon graphics so it looks finished on day one, but every image/video slot is wired to upgrade itself automatically the moment you add real files — no code edits required.

- **Gallery photos** → four real project photos already ship in `images/gallery/` (used in the hero, the "Why" section, and two gallery cards). Two gallery cards still use icon placeholders — drop files into `images/gallery/` using the exact names listed in `images/gallery/README.txt` (`window-replacement.jpg`, `entry-door.jpg`) to replace them.
- **Hero background video** and **"See Us In Action" walkthrough video** → drop `.mp4` files into `videos/` using the exact names listed in `videos/README.txt`. Redeploy and they play automatically; if a file's missing, that section just keeps its current fallback look.

A note on stock or competitor photos: I didn't pull images or video from other companies' websites to fill these in — that's their copyrighted product photography, and using it here would misrepresent whose work it is. The two honest paths forward are (1) your own project photos/video, which is what these slots are built for, or (2) properly licensed stock photography (sites like Unsplash or Pexels offer free-for-commercial-use images) if you want to fill a gap before you have your own shots.

## Contact form

The form currently shows a confirmation message in the browser but doesn't send an email anywhere — it's wired for you to connect a backend. The easiest options:

- **Netlify Forms** (built-in, free): add `data-netlify="true"` and a hidden `form-name` input to the `<form id="contactForm">` tag in `index.html`, redeploy, and submissions will appear in your Netlify dashboard automatically.
- **Formspree / Getform** (no backend needed): sign up, then point the form's `action` attribute at the endpoint they give you.

## File structure

```
index.html      — all page content
styles.css      — all styling (colors, layout, responsive rules)
script.js       — mobile menu, form handling, scroll animations
netlify.toml    — deploy config + basic security headers
images/
  favicon-512.png     — browser tab icon (matches the new brass/charcoal brand mark)
  gallery/            — project photos (four real photos included)
```

Note: the header/footer logo is now an inline animated SVG built directly into `index.html` (not an image file), so it can draw itself in and recolor for the dark footer automatically. `logo.png` is no longer referenced but is left in `images/` in case you want a flat raster version for social sharing, favicons elsewhere, etc.

## Local preview

Just double-click `index.html`, or run a quick local server from this folder:

```
python3 -m http.server 8000
```

Then open `http://localhost:8000`.
