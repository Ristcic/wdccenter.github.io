// WDC Design Center — site scripts

// iOS Safari needs a touchstart listener present in the DOM before it will
// apply :active styles to non-form elements (cards, images, etc). This is a
// no-op listener whose only job is to unlock that behavior so tapping a
// card on iPhone/iPad shows the same lift/glow/zoom effects hovering shows
// on desktop.
document.addEventListener('touchstart', () => {}, { passive: true });

document.addEventListener('DOMContentLoaded', () => {

  // Footer year
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  // Mobile nav toggle
  const header = document.getElementById('header');
  const navToggle = document.getElementById('navToggle');
  if (navToggle && header) {
    navToggle.addEventListener('click', () => {
      const isOpen = header.classList.toggle('open');
      navToggle.classList.toggle('active', isOpen);
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });
    // Close menu when a nav link is tapped
    header.querySelectorAll('.main-nav a').forEach(link => {
      link.addEventListener('click', () => {
        header.classList.remove('open');
        navToggle.classList.remove('active');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  // Add a subtle shadow/glow to the header once the page scrolls
  if (header) {
    const onScroll = () => header.classList.toggle('scrolled', window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  // Optional hero video: if videos/hero-loop.mp4 exists and loads, show it in place
  // of the photo. Silently falls back if the file isn't there.
  const heroVisual = document.getElementById('heroVisual');
  const heroVideo = document.getElementById('heroVideo');
  if (heroVisual && heroVideo) {
    heroVideo.addEventListener('loadeddata', () => heroVisual.classList.add('has-video'));
    heroVideo.addEventListener('error', () => heroVisual.classList.remove('has-video'));
  }

  // Optional walkthrough video: same pattern for the "See Us In Action" section.
  const videoFrame = document.getElementById('videoFrame');
  const walkthroughVideo = document.getElementById('walkthroughVideo');
  if (videoFrame && walkthroughVideo) {
    walkthroughVideo.addEventListener('loadeddata', () => videoFrame.classList.add('has-video'));
    walkthroughVideo.addEventListener('error', () => videoFrame.classList.remove('has-video'));
  }

  // Contact form (demo submit — wire to your backend / form service before launch)
  const form = document.getElementById('contactForm');
  const note = document.getElementById('formNote');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = form.querySelector('#name').value.trim();
      if (!name) return;
      note.textContent = `Thanks, ${name.split(' ')[0]} — we'll be in touch within one business day.`;
      form.reset();
    });
  }

  // Scroll-reveal for cards/sections, staggered within each parent group
  const revealTargets = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    const groups = new Map();
    revealTargets.forEach(el => {
      const parent = el.parentElement;
      if (!groups.has(parent)) groups.set(parent, []);
      groups.get(parent).push(el);
    });
    groups.forEach(items => {
      items.forEach((el, i) => {
        el.style.transitionDelay = `${Math.min(i * 90, 360)}ms`;
      });
    });
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    revealTargets.forEach(el => io.observe(el));
  } else {
    revealTargets.forEach(el => el.classList.add('is-visible'));
  }

  // Animated count-up for hero stats
  const counters = document.querySelectorAll('.stat-num[data-count]');
  if (counters.length && 'IntersectionObserver' in window) {
    const animateCount = (el) => {
      const target = parseInt(el.getAttribute('data-count'), 10) || 0;
      const suffix = el.getAttribute('data-suffix') || '';
      const duration = 1400;
      const start = performance.now();
      const step = (now) => {
        const progress = Math.min((now - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        el.textContent = Math.round(eased * target).toLocaleString() + suffix;
        if (progress < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    };
    const countIo = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          animateCount(entry.target);
          countIo.unobserve(entry.target);
        }
      });
    }, { threshold: 0.6 });
    counters.forEach(el => countIo.observe(el));
  }

});
