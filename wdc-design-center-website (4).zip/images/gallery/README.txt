Four real project photos are already in place here:

  galley-kitchen-white.jpg     White shaker galley kitchen, walnut island
  coastal-blue-kitchen.jpg     Coastal blue custom cabinetry, brass hardware
  classic-white-kitchen.jpg    Bright white kitchen suite (also used in the hero photo)
  moody-charcoal-kitchen.jpg   Moody charcoal & brass kitchen (also used in the "Why" section)

The rest of the "Recent Work" gallery cards use a placeholder icon design
since there's no real photo for them yet — drop files in using these exact
names to replace them with your own project photos:

  window-replacement.jpg   Finished window install (tall card)
  entry-door.jpg           Finished entry door
  french-doors.jpg         French patio door install
  kitchen-island.jpg       Custom kitchen island (tall card)
  bay-window.jpg           Bay window install
  barn-door.jpg            Sliding barn door install
  pantry-cabinets.jpg      Floor-to-ceiling pantry cabinetry (wide card)

Want even more cards? Copy a <figure class="gallery-item reveal"> block in
the "Recent Work" section of index.html, give the <img> a new file name,
and drop the matching photo in here — the grid layout will hold it.

Tips:
  - Landscape or portrait photos, at least 1200px on the long edge, look best.
  - Keep each file under ~500KB (export at ~80% quality) so the page loads fast.
  - If a file is missing, that card just keeps its icon design — nothing breaks.
